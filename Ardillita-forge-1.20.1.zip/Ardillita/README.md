# Ardillita (mod para Minecraft Forge 1.20.1)

Una ardillita pequeña, curiosa y muy mona que trae color y ternura al mundo.

## Cómo conseguir el .jar con GitHub
1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de esta carpeta (incluida la carpeta oculta `.github`).
   Si la subida web no incluye `.github`, crea el archivo a mano con
   *Add file > Create new file* y el nombre `.github/workflows/build.yml`.
3. Ve a la pestaña **Actions**. Se ejecutará solo "Compilar mod (.jar)" (tarda unos minutos).
4. Cuando termine en verde, entra en la ejecución y descarga el artefacto **Ardillita-jar**.
   Dentro está `ardillita-1.0.0.jar`: cópialo a la carpeta `mods` de Forge 1.20.1 (Forge 47.3.0 o superior).

## Cómo se juega
- **Bellota**: se obtiene rompiendo hojas (5 % de probabilidad) o del nido. Es la comida favorita.
- **Domesticar**: dale bellotas a una ardillita salvaje (1 de cada 3 intentos funciona).
- **Quieta / sígueme**: clic derecho con la mano vacía.
- **Traer objetos**: tira al suelo unos objetos, sostén uno igual en la mano y haz clic derecho en tu ardillita: irá a buscarlo y te lo traerá.
- **Regalos**: de vez en cuando te trae una bellota (o una florecita) por sorpresa.
- **Mimos**: bellota a tu ardillita domesticada para curarla. Con la mano vacía puedes coger lo que lleve.
- **Ardillita rosita**: aparece de forma muy rara (1 de cada 30). Para probar:
  `/summon ardillita:ardillita ~ ~ ~ {Variant:1}`
- **Nido de ardillita**: se genera en las copas de los árboles; las salvajes duermen en ellos por la noche. También se craftea (7 palos + 1 bellota).

## Ajustes rápidos (en `ArdillitaEntity.java`)
- `PINK_CHANCE`: probabilidad de la rosita.
- `TAME_CHANCE`: dificultad para domesticar.
