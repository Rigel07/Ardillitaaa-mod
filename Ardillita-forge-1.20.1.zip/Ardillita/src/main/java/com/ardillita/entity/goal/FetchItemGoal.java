package com.ardillita.entity.goal;

import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** El dueño le enseña un objeto: ella busca uno igual en el suelo y se lo trae. */
public class FetchItemGoal extends Goal {
    private final ArdillitaEntity mob;
    private ItemEntity target;
    private int timeout;
    private int repath;

    public FetchItemGoal(ArdillitaEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return mob.getFetchItem() != null && mob.isTame() && !mob.isOrderedToSit() && mob.getOwner() != null;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse() && timeout > 0;
    }

    @Override
    public void start() {
        timeout = 900;
        repath = 0;
        target = null;
    }

    @Override
    public void stop() {
        target = null;
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        LivingEntity owner = mob.getOwner();
        if (owner == null) {
            return;
        }
        timeout--;

        // 1) Ya lleva algo en la boca: se lo entrega al dueño.
        if (!mob.getMainHandItem().isEmpty()) {
            mob.getLookControl().setLookAt(owner, 30.0F, 30.0F);
            if (mob.distanceToSqr(owner) < 4.0D) {
                mob.giveCarriedItemTo(owner);
                mob.clearFetch();
                return;
            }
            if (--repath <= 0) {
                repath = 10;
                mob.getNavigation().moveTo(owner, 1.25D);
            }
            return;
        }

        // 2) Busca el objeto pedido.
        if (target == null || !target.isAlive() || target.getItem().isEmpty()) {
            target = findItem();
            if (target == null) {
                if (owner instanceof Player player) {
                    player.displayClientMessage(Component.translatable("message.ardillita.not_found"), true);
                }
                mob.clearFetch();
                return;
            }
        }

        mob.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (--repath <= 0) {
            repath = 10;
            mob.getNavigation().moveTo(target, 1.3D);
        }

        if (mob.distanceToSqr(target) < 1.8D) {
            ItemStack stack = target.getItem();
            ItemStack one = stack.split(1);
            if (stack.isEmpty()) {
                target.discard();
            } else {
                target.setItem(stack);
            }
            mob.setItemSlot(EquipmentSlot.MAINHAND, one);
            target = null;
        }
    }

    private ItemEntity findItem() {
        List<ItemEntity> items = mob.level().getEntitiesOfClass(ItemEntity.class,
                mob.getBoundingBox().inflate(24.0D, 10.0D, 24.0D),
                e -> e.isAlive() && e.getItem().is(mob.getFetchItem()));
        return items.stream().min(Comparator.comparingDouble(mob::distanceToSqr)).orElse(null);
    }
}
