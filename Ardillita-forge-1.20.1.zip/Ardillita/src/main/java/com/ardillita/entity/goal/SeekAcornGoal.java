package com.ardillita.entity.goal;

import com.ardillita.ModRegistry;
import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Las ardillitas salvajes buscan bellotas sueltas por el suelo (las recogen en Mob#aiStep). */
public class SeekAcornGoal extends Goal {
    private final ArdillitaEntity mob;
    private ItemEntity target;
    private int repath;

    public SeekAcornGoal(ArdillitaEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        if (mob.isTame() || !mob.getMainHandItem().isEmpty() || mob.getRandom().nextInt(60) != 0) {
            return false;
        }
        List<ItemEntity> acorns = mob.level().getEntitiesOfClass(ItemEntity.class,
                mob.getBoundingBox().inflate(10.0D, 4.0D, 10.0D),
                e -> e.isAlive() && e.getItem().is(ModRegistry.ACORN.get()));
        target = acorns.stream().min(Comparator.comparingDouble(mob::distanceToSqr)).orElse(null);
        return target != null;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && mob.getMainHandItem().isEmpty() && !mob.isTame();
    }

    @Override
    public void start() {
        repath = 0;
    }

    @Override
    public void stop() {
        target = null;
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (--repath <= 0) {
            repath = 10;
            mob.getNavigation().moveTo(target, 1.15D);
        }
    }
}
