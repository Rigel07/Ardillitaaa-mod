package com.ardillita.entity.goal;

import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.Level;

import java.util.EnumSet;

/** Busca un tronco cercano, trepa hasta arriba, se queda un ratito curioseando y baja. */
public class ClimbTreeGoal extends Goal {
    private final ArdillitaEntity mob;
    private BlockPos target;   // aire justo encima del último tronco
    private int timeout;
    private int perch;
    private int repath;
    private boolean arrived;

    public ClimbTreeGoal(ArdillitaEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (mob.isInSittingPose() || mob.isOrderedToSit() || mob.isNestSleeping()) {
            return false;
        }
        if (mob.getRandom().nextInt(120) != 0) {
            return false;
        }
        LivingEntity owner = mob.getOwner();
        if (mob.isTame() && (owner == null || mob.distanceToSqr(owner) > 100.0D)) {
            return false;
        }
        target = findTrunkTop();
        return target != null;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && timeout > 0 && !mob.isOrderedToSit() && !(arrived && perch <= 0);
    }

    @Override
    public void start() {
        timeout = 500;
        perch = 0;
        repath = 0;
        arrived = false;
        mob.getNavigation().moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, 1.0D);
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
        target = null;
    }

    @Override
    public void tick() {
        timeout--;
        mob.getLookControl().setLookAt(target.getX() + 0.5D, target.getY() + 0.5D, target.getZ() + 0.5D);

        if (arrived) {
            perch--;
            mob.getNavigation().stop();
            return;
        }
        if (mob.getY() >= target.getY() - 0.2D && !mob.isClimbingTree()) {
            arrived = true;
            perch = 60 + mob.getRandom().nextInt(100);
            mob.getNavigation().stop();
            return;
        }
        if (--repath <= 0) {
            repath = 10;
            mob.getNavigation().moveTo(target.getX() + 0.5D, target.getY(), target.getZ() + 0.5D, 1.0D);
        }
    }

    private BlockPos findTrunkTop() {
        Level level = mob.level();
        RandomSource random = mob.getRandom();
        BlockPos origin = mob.blockPosition();

        for (int i = 0; i < 24; i++) {
            BlockPos p = origin.offset(random.nextInt(17) - 8, random.nextInt(5) - 2, random.nextInt(17) - 8);
            if (!level.getBlockState(p).is(BlockTags.LOGS)) {
                continue;
            }
            BlockPos.MutableBlockPos cursor = p.mutable();
            int guard = 0;
            while (guard++ < 40 && level.getBlockState(cursor.below()).is(BlockTags.LOGS)) {
                cursor.move(Direction.DOWN);
            }
            int height = 1;
            guard = 0;
            while (guard++ < 40 && level.getBlockState(cursor.above()).is(BlockTags.LOGS)) {
                cursor.move(Direction.UP);
                height++;
            }
            if (height >= 3) {
                return new BlockPos(p.getX(), cursor.getY() + 1, p.getZ());
            }
        }
        return null;
    }
}
