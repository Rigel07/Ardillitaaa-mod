package com.ardillita.entity;

import com.ardillita.ModRegistry;
import com.ardillita.entity.goal.ClimbTreeGoal;
import com.ardillita.entity.goal.FetchItemGoal;
import com.ardillita.entity.goal.GiftAcornGoal;
import com.ardillita.entity.goal.PlayWithFriendGoal;
import com.ardillita.entity.goal.SeekAcornGoal;
import com.ardillita.entity.goal.SleepInNestGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.FollowOwnerGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.PanicGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.navigation.WallClimberNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

public class ArdillitaEntity extends TamableAnimal {
    public static final int VARIANT_NORMAL = 0;
    public static final int VARIANT_PINK = 1;

    /** 1 de cada N ardillitas nace rosita. */
    private static final int PINK_CHANCE = 30;
    /** 1 de cada N bellotas consigue domesticarla. */
    private static final int TAME_CHANCE = 3;

    private static final EntityDataAccessor<Integer> DATA_VARIANT =
            SynchedEntityData.defineId(ArdillitaEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_CLIMBING =
            SynchedEntityData.defineId(ArdillitaEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_NEST_SLEEPING =
            SynchedEntityData.defineId(ArdillitaEntity.class, EntityDataSerializers.BOOLEAN);

    /** Objeto que el dueño le ha pedido traer (no se guarda en disco). */
    @Nullable
    private Item fetchItem;
    /** Ticks hasta el próximo regalo de bellota/flor. */
    private int giftCooldown = 0;

    public ArdillitaEntity(EntityType<? extends ArdillitaEntity> type, Level level) {
        super(type, level);
        this.setCanPickUpLoot(true);
        this.setGuaranteedDrop(EquipmentSlot.MAINHAND);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 8.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.3D);
    }

    // ------------------------------------------------------------------ IA

    @Override
    protected PathNavigation createNavigation(Level level) {
        return new WallClimberNavigation(this, level);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
        this.goalSelector.addGoal(2, new PanicGoal(this, 1.5D));
        this.goalSelector.addGoal(3, new FetchItemGoal(this));
        this.goalSelector.addGoal(3, new GiftAcornGoal(this));
        this.goalSelector.addGoal(4, new FollowOwnerGoal(this, 1.1D, 6.0F, 2.0F, false));
        this.goalSelector.addGoal(5, new SleepInNestGoal(this));
        this.goalSelector.addGoal(6, new TemptGoal(this, 1.1D, Ingredient.of(ModRegistry.ACORN.get()), false));
        this.goalSelector.addGoal(7, new SeekAcornGoal(this));
        this.goalSelector.addGoal(8, new ClimbTreeGoal(this));
        this.goalSelector.addGoal(9, new PlayWithFriendGoal(this));
        this.goalSelector.addGoal(10, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(11, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(12, new RandomLookAroundGoal(this));
    }

    // ------------------------------------------------------------- Datos

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_VARIANT, VARIANT_NORMAL);
        this.entityData.define(DATA_CLIMBING, false);
        this.entityData.define(DATA_NEST_SLEEPING, false);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Variant", getVariant());
        tag.putInt("GiftCooldown", giftCooldown);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setVariant(tag.getInt("Variant"));
        giftCooldown = tag.getInt("GiftCooldown");
    }

    public int getVariant() {
        return this.entityData.get(DATA_VARIANT);
    }

    public void setVariant(int variant) {
        this.entityData.set(DATA_VARIANT, variant == VARIANT_PINK ? VARIANT_PINK : VARIANT_NORMAL);
    }

    public boolean isPink() {
        return getVariant() == VARIANT_PINK;
    }

    public boolean isClimbingTree() {
        return this.entityData.get(DATA_CLIMBING);
    }

    private void setClimbingTree(boolean climbing) {
        this.entityData.set(DATA_CLIMBING, climbing);
    }

    public boolean isNestSleeping() {
        return this.entityData.get(DATA_NEST_SLEEPING);
    }

    public void setNestSleeping(boolean sleeping) {
        this.entityData.set(DATA_NEST_SLEEPING, sleeping);
    }

    public int getGiftCooldown() {
        return giftCooldown;
    }

    public void setGiftCooldown(int ticks) {
        this.giftCooldown = ticks;
    }

    // -------------------------------------------------- Pedir objetos

    @Nullable
    public Item getFetchItem() {
        return fetchItem;
    }

    public void startFetch(Item item) {
        this.fetchItem = item;
        setNestSleeping(false);
    }

    public void clearFetch() {
        this.fetchItem = null;
    }

    /** Suelta con cariño lo que lleva en la boca a los pies de {@code target}. */
    public void giveCarriedItemTo(LivingEntity target) {
        ItemStack held = getMainHandItem();
        if (held.isEmpty() || level().isClientSide) {
            return;
        }
        setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        net.minecraft.world.entity.item.ItemEntity drop =
                new net.minecraft.world.entity.item.ItemEntity(level(), getX(), getY() + 0.3D, getZ(), held);
        Vec3 dir = target.position().subtract(position());
        Vec3 flat = new Vec3(dir.x, 0.0D, dir.z).normalize();
        drop.setDeltaMovement(flat.x * 0.12D, 0.2D, flat.z * 0.12D);
        drop.setPickUpDelay(10);
        level().addFreshEntity(drop);

        playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
        if (level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.HEART, getX(), getY() + 0.6D, getZ(), 5, 0.3D, 0.3D, 0.3D, 0.02D);
        }
    }

    // ------------------------------------------------------ Interacción

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        boolean isAcorn = stack.is(ModRegistry.ACORN.get());

        // Salvaje: una bellota puede domesticarla.
        if (!isTame()) {
            if (isAcorn) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    if (this.random.nextInt(TAME_CHANCE) == 0) {
                        tame(player);
                        this.navigation.stop();
                        setTarget(null);
                        setOrderedToSit(false);
                        setInSittingPose(false);
                        getAttribute(Attributes.MAX_HEALTH).setBaseValue(12.0D);
                        setHealth(12.0F);
                        giftCooldown = 2400 + this.random.nextInt(2400);
                        level().broadcastEntityEvent(this, (byte) 7);
                        playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
                    } else {
                        level().broadcastEntityEvent(this, (byte) 6);
                    }
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }

        if (!isOwnedBy(player)) {
            return InteractionResult.PASS;
        }
        if (stack.is(Items.NAME_TAG) || stack.is(Items.LEAD)) {
            return InteractionResult.PASS;
        }

        // Domesticada + bellota: la mima y la cura.
        if (isAcorn) {
            if (!level().isClientSide) {
                if (getHealth() < getMaxHealth()) {
                    if (!player.getAbilities().instabuild) {
                        stack.shrink(1);
                    }
                    heal(2.0F);
                }
                level().broadcastEntityEvent(this, (byte) 7);
                playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Domesticada + cualquier otro objeto en la mano: "tráeme esto".
        if (!stack.isEmpty()) {
            if (!level().isClientSide) {
                startFetch(stack.getItem());
                setOrderedToSit(false);
                setInSittingPose(false);
                player.displayClientMessage(Component.translatable("message.ardillita.fetch", stack.getHoverName()), true);
                playSound(ModRegistry.SOUND_CHITTER.get(), 1.0F, getVoicePitch());
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // Mano vacía: coge lo que lleva, o alterna "quieta" / "sígueme".
        if (!level().isClientSide) {
            ItemStack held = getMainHandItem();
            if (!held.isEmpty()) {
                setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
                clearFetch();
                if (!player.getInventory().add(held)) {
                    player.drop(held, false);
                }
                playSound(ModRegistry.SOUND_HAPPY.get(), 1.0F, getVoicePitch());
            } else {
                boolean sit = !isOrderedToSit();
                setOrderedToSit(sit);
                this.jumping = false;
                this.navigation.stop();
                setTarget(null);
                clearFetch();
                player.displayClientMessage(
                        Component.translatable(sit ? "message.ardillita.stay" : "message.ardillita.follow"), true);
                playSound(ModRegistry.SOUND_CHITTER.get(), 1.0F, getVoicePitch());
            }
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public boolean isFood(ItemStack stack) {
        return false;
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        return null;
    }

    /** Las salvajes recogen bellotas del suelo y las llevan en las manitas. */
    @Override
    public boolean wantsToPickUp(ItemStack stack) {
        return !isTame() && stack.is(ModRegistry.ACORN.get()) && getMainHandItem().isEmpty();
    }

    // ------------------------------------------------------------ Spawn

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag dataTag) {
        if (this.random.nextInt(PINK_CHANCE) == 0) {
            setVariant(VARIANT_PINK);
        }
        if (spawnData == null) {
            spawnData = new AgeableMob.AgeableMobGroupData(false);
        }
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    /** Aparecen en biomas con árboles, y (en el mundo ya generado) cerca de troncos. */
    public static boolean checkArdillitaSpawnRules(EntityType<ArdillitaEntity> type, LevelAccessor level,
                                                   MobSpawnType reason, BlockPos pos, RandomSource random) {
        if (!Animal.checkAnimalSpawnRules(type, level, reason, pos, random)) {
            return false;
        }
        if (reason != MobSpawnType.NATURAL || !(level instanceof ServerLevel serverLevel)) {
            return true;
        }
        for (int i = 0; i < 30; i++) {
            BlockPos p = pos.offset(random.nextInt(13) - 6, random.nextInt(9), random.nextInt(13) - 6);
            if (serverLevel.hasChunkAt(p) && serverLevel.getBlockState(p).is(BlockTags.LOGS)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------- Tick

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide) {
            setClimbingTree(this.horizontalCollision && isNextToTree());
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (!level().isClientSide && isTame() && giftCooldown > 0) {
            giftCooldown--;
        }
    }

    private boolean isNextToTree() {
        BlockPos pos = blockPosition();
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            if (isTreeBlock(pos.relative(dir)) || isTreeBlock(pos.above().relative(dir))) {
                return true;
            }
        }
        return false;
    }

    private boolean isTreeBlock(BlockPos pos) {
        var state = level().getBlockState(pos);
        return state.is(BlockTags.LOGS) || state.is(BlockTags.LEAVES);
    }

    @Override
    public boolean onClimbable() {
        return isClimbingTree();
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false; // las ardillitas siempre caen de pie
    }

    @Override
    protected boolean isImmobile() {
        return super.isImmobile() || isNestSleeping();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (isNestSleeping()) {
            setNestSleeping(false);
        }
        return super.hurt(source, amount);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return dimensions.height * 0.8F;
    }

    // ----------------------------------------------------------- Sonidos

    @Nullable
    @Override
    protected SoundEvent getAmbientSound() {
        return isNestSleeping() ? null : ModRegistry.SOUND_AMBIENT.get();
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModRegistry.SOUND_HURT.get();
    }

    @Override
    protected SoundEvent getDeathSound() {
        return ModRegistry.SOUND_DEATH.get();
    }
}
