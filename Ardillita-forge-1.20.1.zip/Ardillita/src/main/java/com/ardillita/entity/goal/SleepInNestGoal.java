package com.ardillita.entity.goal;

import com.ardillita.ModRegistry;
import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

import java.util.EnumSet;
import java.util.Optional;

/** De noche, las ardillitas salvajes trepan hasta un nido cercano y se duermen en él. */
public class SleepInNestGoal extends Goal {
    private final ArdillitaEntity mob;
    private BlockPos nest;
    private boolean reached;
    private int timeout;
    private int repath;

    public SleepInNestGoal(ArdillitaEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP, Flag.LOOK));
    }

    private boolean isNight() {
        if (mob.level().dimensionType().hasFixedTime()) {
            return false;
        }
        long t = mob.level().getDayTime() % 24000L;
        return t >= 13000L && t < 23000L;
    }

    @Override
    public boolean canUse() {
        if (mob.isTame() || mob.isInSittingPose() || !isNight() || mob.getRandom().nextInt(30) != 0) {
            return false;
        }
        Optional<BlockPos> found = BlockPos.findClosestMatch(mob.blockPosition(), 16, 8,
                p -> mob.level().getBlockState(p).is(ModRegistry.NEST.get()));
        if (found.isEmpty()) {
            return false;
        }
        nest = found.get();
        return true;
    }

    @Override
    public boolean canContinueToUse() {
        if (nest == null || !isNight() || !mob.level().getBlockState(nest).is(ModRegistry.NEST.get())) {
            return false;
        }
        return reached ? mob.isNestSleeping() : timeout > 0;
    }

    @Override
    public void start() {
        reached = false;
        timeout = 700;
        repath = 0;
        mob.getNavigation().moveTo(nest.getX() + 0.5D, nest.getY() + 0.3D, nest.getZ() + 0.5D, 1.0D);
    }

    @Override
    public void stop() {
        mob.setNestSleeping(false);
        mob.getNavigation().stop();
        reached = false;
        nest = null;
    }

    @Override
    public void tick() {
        if (reached) {
            mob.getNavigation().stop();
            return;
        }
        timeout--;
        double dx = mob.getX() - (nest.getX() + 0.5D);
        double dy = mob.getY() - nest.getY();
        double dz = mob.getZ() - (nest.getZ() + 0.5D);
        if (dx * dx + dz * dz < 1.5D && Math.abs(dy) < 1.6D) {
            reached = true;
            mob.getNavigation().stop();
            mob.setNestSleeping(true);
            return;
        }
        if (--repath <= 0) {
            repath = 15;
            mob.getNavigation().moveTo(nest.getX() + 0.5D, nest.getY() + 0.3D, nest.getZ() + 0.5D, 1.0D);
        }
    }
}
