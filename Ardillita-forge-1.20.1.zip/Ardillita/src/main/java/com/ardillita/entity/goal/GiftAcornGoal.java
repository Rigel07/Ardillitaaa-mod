package com.ardillita.entity.goal;

import com.ardillita.ModRegistry;
import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.EnumSet;

/** De vez en cuando, ardillita le trae a su dueño una bellota (o una florecita) como regalo. */
public class GiftAcornGoal extends Goal {
    private static final Item[] FLOWERS = {
            Items.DANDELION, Items.POPPY, Items.BLUE_ORCHID, Items.AZURE_BLUET,
            Items.CORNFLOWER, Items.OXEYE_DAISY, Items.PINK_TULIP, Items.SWEET_BERRIES
    };

    private final ArdillitaEntity mob;
    private int timeout;
    private int repath;

    public GiftAcornGoal(ArdillitaEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!mob.isTame() || mob.isOrderedToSit() || mob.isInSittingPose()) {
            return false;
        }
        if (mob.getFetchItem() != null || !mob.getMainHandItem().isEmpty() || mob.getGiftCooldown() > 0) {
            return false;
        }
        LivingEntity owner = mob.getOwner();
        if (owner == null || owner.isSpectator() || mob.distanceToSqr(owner) > 400.0D) {
            return false;
        }
        return mob.getRandom().nextInt(20) == 0;
    }

    @Override
    public boolean canContinueToUse() {
        LivingEntity owner = mob.getOwner();
        return owner != null && mob.isTame() && !mob.isOrderedToSit() && mob.getFetchItem() == null
                && !mob.getMainHandItem().isEmpty() && timeout > 0;
    }

    @Override
    public void start() {
        timeout = 600;
        repath = 0;
        Item gift = mob.getRandom().nextInt(100) < 85
                ? ModRegistry.ACORN.get()
                : FLOWERS[mob.getRandom().nextInt(FLOWERS.length)];
        mob.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(gift));
    }

    @Override
    public void tick() {
        LivingEntity owner = mob.getOwner();
        if (owner == null) {
            return;
        }
        timeout--;
        mob.getLookControl().setLookAt(owner, 30.0F, 30.0F);
        if (mob.distanceToSqr(owner) < 4.0D) {
            mob.giveCarriedItemTo(owner);
            mob.setGiftCooldown(6000 + mob.getRandom().nextInt(6000));
            return;
        }
        if (--repath <= 0) {
            repath = 10;
            mob.getNavigation().moveTo(owner, 1.2D);
        }
    }

    @Override
    public void stop() {
        mob.getNavigation().stop();
        // Si se interrumpe el regalo (p. ej. "quédate quieta"), deja la bellota en el suelo.
        if (mob.getFetchItem() == null && !mob.getMainHandItem().isEmpty()) {
            mob.spawnAtLocation(mob.getMainHandItem());
            mob.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
            mob.setGiftCooldown(1200);
        }
    }
}
