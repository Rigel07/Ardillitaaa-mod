package com.ardillita.entity.goal;

import com.ardillita.ModRegistry;
import com.ardillita.entity.ArdillitaEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Juego del pilla-pilla: una persigue a otra ardillita cercana, saltitos incluidos. */
public class PlayWithFriendGoal extends Goal {
    private final ArdillitaEntity mob;
    private ArdillitaEntity friend;
    private int timeout;
    private int repath;

    public PlayWithFriendGoal(ArdillitaEntity mob) {
        this.mob = mob;
        setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (mob.isInSittingPose() || mob.isNestSleeping() || mob.getRandom().nextInt(160) != 0) {
            return false;
        }
        List<ArdillitaEntity> others = mob.level().getEntitiesOfClass(ArdillitaEntity.class,
                mob.getBoundingBox().inflate(10.0D, 4.0D, 10.0D),
                e -> e != mob && !e.isNestSleeping() && !e.isInSittingPose());
        friend = others.stream().min(Comparator.comparingDouble(mob::distanceToSqr)).orElse(null);
        return friend != null;
    }

    @Override
    public boolean canContinueToUse() {
        return friend != null && friend.isAlive() && timeout > 0 && !mob.isInSittingPose() && !mob.isOrderedToSit();
    }

    @Override
    public void start() {
        timeout = 140;
        repath = 0;
    }

    @Override
    public void stop() {
        friend = null;
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        timeout--;
        mob.getLookControl().setLookAt(friend, 30.0F, 30.0F);

        if (mob.distanceToSqr(friend) > 4.0D) {
            if (--repath <= 0) {
                repath = 8;
                mob.getNavigation().moveTo(friend, 1.35D);
            }
            return;
        }

        if (mob.onGround() && mob.getRandom().nextInt(6) == 0) {
            mob.getJumpControl().jump();
        }
        if (mob.getRandom().nextInt(10) == 0) {
            Vec3 away = DefaultRandomPos.getPosAway(friend, 8, 4, mob.position());
            if (away != null) {
                friend.getNavigation().moveTo(away.x, away.y, away.z, 1.5D);
            }
            if (mob.getRandom().nextInt(3) == 0) {
                mob.playSound(ModRegistry.SOUND_CHITTER.get(), 0.8F, 1.0F + mob.getRandom().nextFloat() * 0.3F);
            }
        }
    }
}
