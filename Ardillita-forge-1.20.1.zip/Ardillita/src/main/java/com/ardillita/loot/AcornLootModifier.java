package com.ardillita.loot;

import com.ardillita.ModRegistry;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.parameters.LootContextParams;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;

/** Las hojas pueden soltar bellotas (no si se rompen con tijeras). */
public class AcornLootModifier extends LootModifier {
    public static final Codec<AcornLootModifier> CODEC = RecordCodecBuilder.create(inst ->
            codecStart(inst)
                    .and(Codec.FLOAT.optionalFieldOf("chance", 0.05F).forGetter(m -> m.chance))
                    .apply(inst, AcornLootModifier::new));

    private final float chance;

    public AcornLootModifier(LootItemCondition[] conditions, float chance) {
        super(conditions);
        this.chance = chance;
    }

    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> generatedLoot, LootContext context) {
        BlockState state = context.getParamOrNull(LootContextParams.BLOCK_STATE);
        if (state != null && state.is(BlockTags.LEAVES)) {
            ItemStack tool = context.getParamOrNull(LootContextParams.TOOL);
            boolean shears = tool != null && tool.canPerformAction(ToolActions.SHEARS_DIG);
            if (!shears && context.getRandom().nextFloat() < chance) {
                generatedLoot.add(new ItemStack(ModRegistry.ACORN.get()));
            }
        }
        return generatedLoot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }
}
