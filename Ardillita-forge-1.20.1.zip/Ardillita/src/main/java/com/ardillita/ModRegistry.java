package com.ardillita;

import com.ardillita.block.ArdillitaNestBlock;
import com.ardillita.entity.ArdillitaEntity;
import com.ardillita.loot.AcornLootModifier;
import com.ardillita.worldgen.SquirrelNestFeature;
import com.mojang.serialization.Codec;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModRegistry {
    private ModRegistry() {}

    private static final String ID = ArdillitaMod.MOD_ID;

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ID);
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(ForgeRegistries.FEATURES, ID);
    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ID);

    // ---- Sonidos (se mapean en assets/ardillita/sounds.json) ----
    public static final RegistryObject<SoundEvent> SOUND_AMBIENT = sound("entity.ardillita.ambient");
    public static final RegistryObject<SoundEvent> SOUND_HURT = sound("entity.ardillita.hurt");
    public static final RegistryObject<SoundEvent> SOUND_DEATH = sound("entity.ardillita.death");
    public static final RegistryObject<SoundEvent> SOUND_HAPPY = sound("entity.ardillita.happy");
    public static final RegistryObject<SoundEvent> SOUND_CHITTER = sound("entity.ardillita.chitter");

    // ---- Bloques ----
    public static final RegistryObject<Block> NEST = BLOCKS.register("ardillita_nest",
            () -> new ArdillitaNestBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BROWN)
                    .strength(0.4F)
                    .sound(SoundType.GRASS)
                    .noOcclusion()));

    // ---- Entidad ----
    public static final RegistryObject<EntityType<ArdillitaEntity>> ARDILLITA = ENTITIES.register("ardillita",
            () -> EntityType.Builder.<ArdillitaEntity>of(ArdillitaEntity::new, MobCategory.CREATURE)
                    .sized(0.4F, 0.55F)
                    .clientTrackingRange(8)
                    .build(ID + ":ardillita"));

    // ---- Objetos ----
    public static final RegistryObject<Item> ACORN = ITEMS.register("acorn",
            () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> NEST_ITEM = ITEMS.register("ardillita_nest",
            () -> new BlockItem(NEST.get(), new Item.Properties()));
    public static final RegistryObject<Item> SPAWN_EGG = ITEMS.register("ardillita_spawn_egg",
            () -> new ForgeSpawnEggItem(ARDILLITA, 0xB5651D, 0xF4D3B4, new Item.Properties()));

    // ---- Worldgen ----
    public static final RegistryObject<Feature<NoneFeatureConfiguration>> NEST_FEATURE = FEATURES.register("nest",
            () -> new SquirrelNestFeature(NoneFeatureConfiguration.CODEC));

    // ---- Loot: bellotas al romper hojas ----
    public static final RegistryObject<Codec<? extends IGlobalLootModifier>> ACORN_LOOT =
            LOOT_MODIFIERS.register("acorn_from_leaves", () -> AcornLootModifier.CODEC);

    // ---- Pestaña creativa ----
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("ardillita_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.ardillita"))
                    .icon(() -> new ItemStack(ACORN.get()))
                    .displayItems((params, output) -> {
                        output.accept(ACORN.get());
                        output.accept(NEST_ITEM.get());
                        output.accept(SPAWN_EGG.get());
                    })
                    .build());

    private static RegistryObject<SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ID, name)));
    }

    public static void register(IEventBus bus) {
        SOUNDS.register(bus);
        BLOCKS.register(bus);
        ITEMS.register(bus);
        ENTITIES.register(bus);
        FEATURES.register(bus);
        LOOT_MODIFIERS.register(bus);
        TABS.register(bus);
    }
}
