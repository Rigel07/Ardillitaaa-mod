package com.ardillita.client;

import com.ardillita.entity.ArdillitaEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Dibuja lo que lleva en las manitas (bellota, flor, objeto pedido...) delante del pecho. */
public class HeldItemLayer extends RenderLayer<ArdillitaEntity, ArdillitaModel> {
    private final ItemRenderer itemRenderer;

    public HeldItemLayer(RenderLayerParent<ArdillitaEntity, ArdillitaModel> parent, ItemRenderer itemRenderer) {
        super(parent);
        this.itemRenderer = itemRenderer;
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, ArdillitaEntity entity,
                       float limbSwing, float limbSwingAmount, float partialTick, float ageInTicks,
                       float netHeadYaw, float headPitch) {
        ItemStack stack = entity.getMainHandItem();
        if (stack.isEmpty() || entity.isNestSleeping()) {
            return;
        }
        poseStack.pushPose();
        // Coordenadas del modelo (en píxeles/16): justo delante del pecho, a la altura de las patitas.
        poseStack.translate(0.0F, 20.0F / 16.0F, -4.5F / 16.0F);
        // El renderer de entidades voltea el eje Y/X: lo deshacemos para que el objeto se vea derecho.
        poseStack.mulPose(Axis.ZP.rotationDegrees(180.0F));
        poseStack.scale(0.8F, 0.8F, 0.8F);
        this.itemRenderer.renderStatic(stack, ItemDisplayContext.GROUND, packedLight, OverlayTexture.NO_OVERLAY,
                poseStack, buffer, entity.level(), entity.getId());
        poseStack.popPose();
    }
}
