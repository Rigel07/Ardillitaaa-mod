package com.ardillita.client;

import com.ardillita.entity.ArdillitaEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/** Modelo "chibi": cabezota, cuerpecito y colita enorme. Textura 64x64. */
public class ArdillitaModel extends EntityModel<ArdillitaEntity> {
    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart tail;
    private final ModelPart legFL;
    private final ModelPart legFR;
    private final ModelPart legBL;
    private final ModelPart legBR;

    public ArdillitaModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = root.getChild("head");
        this.tail = root.getChild("tail");
        this.legFL = root.getChild("leg_fl");
        this.legFR = root.getChild("leg_fr");
        this.legBL = root.getChild("leg_bl");
        this.legBR = root.getChild("leg_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition p = mesh.getRoot();

        p.addOrReplaceChild("body",
                CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -3.0F, -3.0F, 6.0F, 6.0F, 6.0F),
                PartPose.offset(0.0F, 19.0F, 0.0F));

        p.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-4.0F, -7.0F, -4.0F, 8.0F, 7.0F, 7.0F)
                        .texOffs(32, 0).addBox(-4.0F, -10.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                        .texOffs(40, 0).addBox(2.0F, -10.0F, -2.0F, 2.0F, 3.0F, 1.0F)
                        .texOffs(48, 0).addBox(-1.0F, -3.0F, -5.0F, 2.0F, 2.0F, 1.0F),
                PartPose.offset(0.0F, 17.0F, -1.0F));

        p.addOrReplaceChild("tail",
                CubeListBuilder.create()
                        .texOffs(0, 38).addBox(-2.0F, -10.0F, 0.0F, 4.0F, 10.0F, 4.0F)
                        .texOffs(20, 38).addBox(-2.0F, -13.0F, -1.0F, 4.0F, 3.0F, 4.0F),
                PartPose.offset(0.0F, 21.0F, 3.0F));

        p.addOrReplaceChild("leg_fl",
                CubeListBuilder.create().texOffs(26, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(2.0F, 21.0F, -2.0F));
        p.addOrReplaceChild("leg_fr",
                CubeListBuilder.create().texOffs(36, 16).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 3.0F, 2.0F),
                PartPose.offset(-2.0F, 21.0F, -2.0F));
        p.addOrReplaceChild("leg_bl",
                CubeListBuilder.create().texOffs(0, 30).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(2.5F, 21.0F, 2.0F));
        p.addOrReplaceChild("leg_br",
                CubeListBuilder.create().texOffs(14, 30).addBox(-1.5F, 0.0F, -1.5F, 3.0F, 3.0F, 3.0F),
                PartPose.offset(-2.5F, 21.0F, 2.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(ArdillitaEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        boolean sleeping = entity.isNestSleeping();
        boolean sitting = entity.isInSittingPose();
        boolean climbing = entity.isClimbingTree();
        boolean resting = sleeping || sitting;

        // Saltito al andar
        float bounce = resting || climbing ? 0.0F : Mth.abs(Mth.sin(limbSwing * 0.7F)) * limbSwingAmount * 1.6F;

        float bodyY = 19.0F;
        float headY = 17.0F;
        float tailY = 21.0F;
        if (sitting && !sleeping) {
            bodyY = 20.0F;
            headY = 18.0F;
            tailY = 23.0F;
        } else if (sleeping) {
            bodyY = 20.5F;
            headY = 19.5F;
            tailY = 23.5F;
        }

        body.y = bodyY - bounce;
        head.y = headY - bounce;
        tail.y = tailY - bounce;
        legFL.y = 21.0F - bounce;
        legFR.y = 21.0F - bounce;
        legBL.y = 21.0F - bounce;
        legBR.y = 21.0F - bounce;

        // Cabeza
        if (sleeping) {
            head.xRot = 0.8F;
            head.yRot = 0.0F;
        } else if (climbing) {
            head.xRot = -0.5F;
            head.yRot = netHeadYaw * Mth.DEG_TO_RAD * 0.5F;
        } else {
            head.xRot = headPitch * Mth.DEG_TO_RAD;
            head.yRot = netHeadYaw * Mth.DEG_TO_RAD;
        }

        // Patitas
        if (climbing) {
            float s = Mth.sin(ageInTicks * 0.8F) * 0.9F;
            legFL.xRot = s;
            legFR.xRot = -s;
            legBL.xRot = -s;
            legBR.xRot = s;
        } else if (resting) {
            legFL.xRot = 0.0F;
            legFR.xRot = 0.0F;
            legBL.xRot = -1.3F;
            legBR.xRot = -1.3F;
        } else {
            float swing = Mth.cos(limbSwing * 0.7F) * 1.2F * limbSwingAmount;
            legFL.xRot = swing;
            legFR.xRot = swing;
            legBL.xRot = -swing;
            legBR.xRot = -swing;
        }

        // Colita: se mece suavemente y se echa hacia atrás al correr
        tail.xRot = 0.2F + Mth.cos(ageInTicks * 0.12F) * 0.04F + limbSwingAmount * 0.35F;
        tail.zRot = Mth.sin(ageInTicks * 0.1F) * (sleeping ? 0.02F : 0.07F);
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
