package com.ardillita.client;

import com.ardillita.ArdillitaMod;
import com.ardillita.entity.ArdillitaEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ArdillitaRenderer extends MobRenderer<ArdillitaEntity, ArdillitaModel> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(ArdillitaMod.MOD_ID, "ardillita"), "main");

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ArdillitaMod.MOD_ID, "textures/entity/ardillita.png");
    private static final ResourceLocation TEXTURE_PINK =
            new ResourceLocation(ArdillitaMod.MOD_ID, "textures/entity/ardillita_rosita.png");

    public ArdillitaRenderer(EntityRendererProvider.Context context) {
        super(context, new ArdillitaModel(context.bakeLayer(LAYER)), 0.25F);
        this.addLayer(new HeldItemLayer(this, context.getItemRenderer()));
    }

    @Override
    public ResourceLocation getTextureLocation(ArdillitaEntity entity) {
        return entity.isPink() ? TEXTURE_PINK : TEXTURE;
    }

    /** El modelo mide ~1 bloque: lo reducimos a ~0.5 bloques como en el diseño. */
    @Override
    protected void scale(ArdillitaEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.55F, 0.55F, 0.55F);
    }
}
