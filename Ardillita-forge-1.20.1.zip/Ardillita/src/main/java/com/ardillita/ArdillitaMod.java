package com.ardillita;

import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ArdillitaMod.MOD_ID)
public class ArdillitaMod {
    public static final String MOD_ID = "ardillita";

    public ArdillitaMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModRegistry.register(modBus);
    }
}
