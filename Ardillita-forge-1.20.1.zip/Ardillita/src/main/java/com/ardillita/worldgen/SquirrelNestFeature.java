package com.ardillita.worldgen;

import com.ardillita.ModRegistry;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/** Coloca un nidito de ardillita en lo alto de la copa de un árbol (sobre las hojas, cerca del tronco). */
public class SquirrelNestFeature extends Feature<NoneFeatureConfiguration> {

    public SquirrelNestFeature(Codec<NoneFeatureConfiguration> codec) {
        super(codec);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();

        for (int dy = 0; dy >= -3; dy--) {
            BlockPos pos = origin.offset(0, dy, 0);
            if (!level.isEmptyBlock(pos)) {
                continue;
            }
            BlockState below = level.getBlockState(pos.below());
            if (below.is(BlockTags.LEAVES) && hasLogNearby(level, pos)) {
                level.setBlock(pos, ModRegistry.NEST.get().defaultBlockState(), 2);
                return true;
            }
        }
        return false;
    }

    private static boolean hasLogNearby(WorldGenLevel level, BlockPos pos) {
        for (int dx = -3; dx <= 3; dx++) {
            for (int dz = -3; dz <= 3; dz++) {
                for (int dy = -6; dy <= 0; dy++) {
                    if (level.getBlockState(pos.offset(dx, dy, dz)).is(BlockTags.LOGS)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
